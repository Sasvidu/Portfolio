﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Functions
{
    public partial class Multiply : Form
    {
        public Multiply()
        {
            InitializeComponent();
        }

        private int cal(int n1, int n2)
        {
            int sum = n1 * n2;
            return sum;
        }

        private void Multiply_Load(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            int t1 = int.Parse(textBox1.Text);
            int t2 = int.Parse(textBox2.Text);
            MessageBox.Show("The product is : " + cal(t1,t2), "Calculated!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }
    }
}
