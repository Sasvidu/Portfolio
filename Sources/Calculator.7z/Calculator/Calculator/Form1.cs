﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBox3.Enabled = false;
        }

        float n1, n2, ans;
        string str;
   
        private void GetNumbers()
        {
            n1 = float.Parse(textBox1.Text);
            n2 = float.Parse(textBox2.Text);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if ((textBox1.Text != "") && (textBox2.Text != ""))
                {
                    GetNumbers();
                    ans = n1 + n2;
                    textBox3.Text = ans.ToString();
                    str = n1.ToString() + " + " + n2.ToString() + " = " + ans.ToString();
                    listBox1.Items.Insert(0, str);
                }
                else
                {
                    MessageBox.Show("You must enter two numbers select the desired operator to get an answer.", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch
            {
                MessageBox.Show("An error occured.\nTry Entering Numbers in the Textboxes.", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                textBox1.Clear();
                textBox2.Clear();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if ((textBox1.Text != "") && (textBox2.Text != ""))
                {
                    GetNumbers();
                    ans = n1 - n2;
                    textBox3.Text = ans.ToString();
                    str = n1.ToString() + " - " + n2.ToString() + " = " + ans.ToString();
                    listBox1.Items.Insert(0, str);
                }
                else
                {
                    MessageBox.Show("You must enter two numbers select the desired operator to get an answer.", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch
            {
                MessageBox.Show("An error occured.\nTry Entering Numbers in the Textboxes.", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                textBox1.Clear();
                textBox2.Clear();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if ((textBox1.Text != "") && (textBox2.Text != ""))
                {
                    GetNumbers();
                    ans = n1 * n2;
                    textBox3.Text = ans.ToString();
                    str = n1.ToString() + " x " + n2.ToString() + " = " + ans.ToString();
                    listBox1.Items.Insert(0, str);
                }
                else
                {
                    MessageBox.Show("You must enter two numbers select the desired operator to get an answer.", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch
            {
                MessageBox.Show("An error occured.\nTry Entering Numbers in the Textboxes.", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                textBox1.Clear();
                textBox2.Clear();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                if ((textBox1.Text != "") && (textBox2.Text != ""))
                {
                    GetNumbers();
                    ans = n1 / n2;
                    textBox3.Text = ans.ToString();
                    str = n1.ToString() + " / " + n2.ToString() + " = " + ans.ToString();
                    listBox1.Items.Insert(0, str);
                }
                else
                {
                    MessageBox.Show("You must enter two numbers select the desired operator to get an answer.", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch
            {
                MessageBox.Show("An error occured.\nTry Entering Numbers in the Textboxes.", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                textBox1.Clear();
                textBox2.Clear();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            textBox3.Clear();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
