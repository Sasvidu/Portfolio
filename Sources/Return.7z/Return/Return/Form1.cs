﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Return
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private int max(int n1,int n2,int n3,int n4,int n5)
        {
            int[] ar = { n1, n2, n3, n4, n5 };
            int maxim = ar[0];
            for(int i = 1; i < ar.Length; i++)
            {
                if (ar[i] > maxim)
                {
                    maxim = ar[i];
                }
            }
            return maxim;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            int t1 = int.Parse(textBox1.Text);
            int t2 = int.Parse(textBox2.Text);
            int t3 = int.Parse(textBox3.Text);
            int t4 = int.Parse(textBox4.Text);
            int t5 = int.Parse(textBox5.Text);
            MessageBox.Show("Maximum number is : " + max(t1, t2, t3, t4, t5), "Great!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }
    }
}
