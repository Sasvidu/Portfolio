﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Return
{
    public partial class ret2 : Form
    {
        public ret2()
        {
            InitializeComponent();
        }

        private int max(int n1,int n2)
        {
            if (n1 > n2)
            {
                return n1;
            }
            else
            {
                return n2;
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            int t1 = int.Parse(textBox1.Text);
            int t2 = int.Parse(textBox2.Text);
            int t3 = int.Parse(textBox3.Text);

           // int r = max(t1, t2);
            int fn = max(t3, max(t1,t2));
            MessageBox.Show(fn.ToString(), "Hi", MessageBoxButtons.OK,MessageBoxIcon.Asterisk);
        }
    }
}
