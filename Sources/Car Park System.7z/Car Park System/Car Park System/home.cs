﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Car_Park_System
{
    public partial class home : Form
    {
        public home()
        {
            InitializeComponent();
        }

        private void ManageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cars o = new cars();
            o.Show();
        }

        private void AllCarsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            All_Cars w = new All_Cars();
            w.Show();
        }

        private void HelpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Welcome to the car park system!\nHere you can add the parked cars, update parked cars and remove parked cars\n\nThankyou for using this product!\n\nSystem developed by, **The 5 Dragons**","Help",MessageBoxButtons.OK,MessageBoxIcon.Information);
        }
    }
}
