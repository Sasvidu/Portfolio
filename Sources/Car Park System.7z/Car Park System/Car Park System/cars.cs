﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Car_Park_System
{
    public partial class cars : Form
    {
        public cars()
        {
            InitializeComponent();
            fillDataGrid();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\csn\Desktop\Programs\Visual\Form\Car Park System\Car Park System\Car Park System.mdf;Integrated Security=True");


        private void Button1_Click(object sender, EventArgs e)
        {
            try
            {

                string carno = textBox1.Text;
                string color = textBox2.Text;
                string model = textBox3.Text;
                string nm = textBox4.Text;
                int tel = int.Parse(textBox5.Text);
                DateTime time = DateTime.Parse(dateTimePicker1.Text);

                //sql query
                string query_insert = "INSERT INTO Cars VALUES('" + carno + "','" + color + "','" + model + "','" + nm + "'," + tel + ",'" + time + "')";

                SqlCommand cmd = new SqlCommand(query_insert, con);
                con.Open();
                cmd.ExecuteNonQuery();

                MessageBox.Show("Saved Successfuly!", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Whiling Saving" + ex, "saving", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            finally
            {
                con.Close();
                fillDataGrid();
                ClearData();
            }

        }
        public void fillDataGrid()
        {
            try
            {
                con.Open();
                SqlDataAdapter z = new SqlDataAdapter(@"SELECT * FROM Cars", con);
                DataTable A = new DataTable();
                dataGridView1.DataSource = A;
                z.Fill(A);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");


            }
            finally
            {
                con.Close();
            }
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string id = textBox6.Text;
                string quert_search = "SELECT * FROM student WHERE id = '" + id + "'";
                SqlCommand cmnd = new SqlCommand(quert_search, con);
                SqlDataReader r = cmnd.ExecuteReader();
                while (r.Read())
                {
                    textBox1.Text = r[1].ToString();
                    textBox2.Text = r[2].ToString();
                    textBox3.Text = r[3].ToString();
                    textBox4.Text = r[4].ToString();
                    textBox5.Text = r[5].ToString();
                    dateTimePicker1.Text = r[6].ToString();
                }

                MessageBox.Show("Searching Successfuly", "Searching", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            catch (Exception ex)
            {
                MessageBox.Show("Error Whiling Searching" + ex, "Searching", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {
                con.Close();
            }
        }

        private void ClearData()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            dateTimePicker1.Text = "";
        }

        private void Button4_Click_1(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string id = textBox6.Text;
                string quert_search = "SELECT * FROM Cars WHERE id = '" + id + "'";
                SqlCommand cmnd = new SqlCommand(quert_search, con);
                SqlDataReader r = cmnd.ExecuteReader();
                while (r.Read())
                {
                    textBox1.Text = r[1].ToString();
                    textBox2.Text = r[2].ToString();
                    textBox3.Text = r[3].ToString();
                    textBox4.Text = r[4].ToString();
                    textBox5.Text = r[5].ToString();
                }
                
                MessageBox.Show("Searching Successfuly", "Searching", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Whiling Searching" + ex, "Searching", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {
                con.Close();
            }
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            try
            {

                string id = textBox6.Text;
                string carno = textBox1.Text;
                string color = textBox2.Text;
                string model=textBox3.Text;
                string name = textBox4.Text;
                int tel = int.Parse(textBox5.Text);
                DateTime time = DateTime.Parse(dateTimePicker1.Text);


                //sql query
                string query_update = "UPDATE Cars SET CarNo='" + carno + "',Color='" + color + "',ModelNo='" + model + "',OwnerName='" + name + "',Ownertel='" + tel + "',Time='" + time + "' WHERE id='" + id + "'";

                SqlCommand cmd = new SqlCommand(query_update, con);
                con.Open();
                cmd.ExecuteNonQuery();

                MessageBox.Show("Updated Successfuly!", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);


            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Whiling Saving" + ex, "saving", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            finally
            {
                con.Close();
                fillDataGrid();
                ClearData();
            }

        }

        private void Button3_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string id = textBox6.Text;
                
                string query_delete = "DELETE FROM Cars WHERE id ='" + id + "'";

                SqlCommand cmd = new SqlCommand(query_delete, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Delete Successfuly!", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Whiling Deleting" + ex, "Deleting", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {
                con.Close();
                fillDataGrid();
                ClearData();
            }
        }

        private void Cars_Load(object sender, EventArgs e)
        {

        }
    }
}

