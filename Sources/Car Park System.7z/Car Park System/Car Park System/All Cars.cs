﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Car_Park_System
{
    public partial class All_Cars : Form
    {
        public All_Cars()
        {
            InitializeComponent();
            fillDataGrid();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\csn\Desktop\Programs\Visual\Form\Car Park System\Car Park System\Car Park System.mdf;Integrated Security=True");

        private void All_Cars_Load(object sender, EventArgs e)
        {

        }

        public void fillDataGrid()
        {
            try
            {
                con.Open();
                SqlDataAdapter z = new SqlDataAdapter(@"SELECT * FROM Cars", con);
                DataTable A = new DataTable();
                dataGridView1.DataSource = A;
                z.Fill(A);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");


            }
            finally
            {
                con.Close();
            }
        }
    }
}
