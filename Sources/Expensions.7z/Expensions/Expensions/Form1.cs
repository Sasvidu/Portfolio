﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Expensions
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBox3.Enabled = false;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                float n1 = float.Parse(textBox1.Text);
                float n2 = float.Parse(textBox2.Text);
                float r = n1 + n2;
                textBox3.Text = r.ToString();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Invalid number or text is entered!\n\nError :\n\n" + ex, "Invalid Input!", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                textBox3.Clear();
            }
            finally
            {
                textBox1.Clear();
                textBox2.Clear();
            }
        }
    }
}
